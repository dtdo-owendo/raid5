/*
    Dung Tien Do
    U20764476
    This program implements a RAID 5 controller that distributes data from a single regular disk across an array of N disks with parity for redundancy.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

// Maximum number of disks supported in the array
#define MAX_DISKS 16
// Maximum block size supported (4KB)
#define MAX_BLOCK_SIZE 4096

/*
    Computes parity block using XOR operation
    parity: output buffer for parity block
    blocks: array of data blocks to compute parity from
    block_count: number of data blocks
    lock_size: size of each block in bytes
*/
void compute_parity(uint8_t *parity, uint8_t **blocks, int block_count, int block_size) {
    memset(parity, 0, block_size); // Initialize parity block to zeros
    for (int i = 0; i < block_count; i++) {
        for (int j = 0; j < block_size; j++) {
            parity[j] ^= blocks[i][j]; // XOR each byte with corresponding bytes in data blocks
        }
    }
}

/*
    Converts 2-character hex string to byte value
    hex: input hex string (2 characters)
    Returns: converted byte value
*/
int hex_to_byte(const char *hex) {
    int value;
    sscanf(hex, "%02x", &value); // Parse hex string to integer
    return value;
}

/*
    Converts byte value to 2-character hex string
    hex: output buffer (must have space for 2 chars + null terminator)
    byte: input byte value to convert
*/
void byte_to_hex(char *hex, uint8_t byte) {
    sprintf(hex, "%02x", byte); // Format byte as 2-digit hex
}

/*
    Reads hexadecimal data from file into binary buffer
    filename: input file path
    buffer: output buffer for binary data
    bytes_to_read: number of bytes to read
*/
int read_hex_file(const char *filename, uint8_t *buffer, int bytes_to_read) {
    FILE *file = fopen(filename, "r");
    if (!file) return -1; // Return error if file can't be opened

    char hex[3] = {0}; // Buffer for 2 hex chars + null terminator
    for (int i = 0; i < bytes_to_read; i++) {
        if (fread(hex, 2, 1, file) != 1) { // Read 2 hex chars at a time
            fclose(file);
            return -1; // Return error if read fails
        }
        buffer[i] = hex_to_byte(hex); // Convert hex to binary and store
    }
    fclose(file);
    return 0; // Success
}

/*
    Writes binary data to file as hexadecimal
    filename: output file path
    buffer: input data buffer
    bytes_to_write: number of bytes to write
*/
int write_hex_file(const char *filename, uint8_t *buffer, int bytes_to_write) {
    FILE *file = fopen(filename, "w");
    if (!file) return -1; // Return error if file can't be opened

    char hex[3] = {0}; // Buffer for hex conversion
    for (int i = 0; i < bytes_to_write; i++) {
        byte_to_hex(hex, buffer[i]); // Convert byte to hex
        if (fwrite(hex, 2, 1, file) != 1) { // Write 2 hex chars
            fclose(file);
            return -1; // Return error if write fails
        }
    }
    fputc('\n', file); // Add newline at end of file
    fclose(file);
    return 0; // Success
}

int main(int argc, char *argv[]) {
    // Check for minimum number of arguments
    if (argc < 6) {
        fprintf(stderr, "Usage: %s B J reg_disk K disk0 disk1 ... diskN\n", argv[0]);
        return 1;
    }

    // Parse and validate command line arguments
    int B = atoi(argv[1]); // Block size
    int J = atoi(argv[2]); // Input data size
    const char *reg_disk_path = argv[3]; // Input file path
    int K = atoi(argv[4]); // Disk capacity
    int N = argc - 5; // Number of disks
    const char *disk_paths[MAX_DISKS]; // Output file paths
    
    // Validate we have enough disks
    if (N < 3) {
        fprintf(stderr, "RAID 5 requires at least 3 disks\n");
        return 1;
    }

    // Store output file paths
    for (int i = 0; i < N; i++) {
        disk_paths[i] = argv[5 + i];
    }

    // Validate all parameters meet requirements
    if (B < 1 || B > MAX_BLOCK_SIZE || J % B != 0 || K % B != 0 || K*(N-1) < J) {
        fprintf(stderr, "Invalid parameters\n");
        return 1;
    }

    // Read input data from regular disk file
    uint8_t *reg_disk = malloc(J); // Allocate buffer for input data
    if (!reg_disk || read_hex_file(reg_disk_path, reg_disk, J) != 0) {
        fprintf(stderr, "Failed to read regular disk\n");
        free(reg_disk);
        return 1;
    }

    // Initialize RAID disk buffers
    uint8_t *disks[MAX_DISKS]; // Array of disk buffers
    for (int i = 0; i < N; i++) {
        disks[i] = calloc(K, 1); // Allocate and zero-initialize each disk
        if (!disks[i]) {
            fprintf(stderr, "Memory allocation failed\n");
            // Clean up already allocated disks before exiting
            for (int j = 0; j < i; j++) free(disks[j]);
            free(reg_disk);
            return 1;
        }
    }

    // Calculate number of blocks and stripes needed
    int blocks_in_reg = J / B; // Total blocks in input
    // Calculate stripes with ceiling division: ceil(blocks/(N-1))
    int stripes = (blocks_in_reg + (N-1) - 1) / (N-1); 
    int block_idx = 0; // Tracks current block being processed

    // Distribute blocks across RAID array with parity
    for (int stripe = 0; stripe < stripes; stripe++) {
        // Calculate parity disk for this stripe (left-symmetric)
        int parity_disk = (N - 1) - (stripe % N);
        uint8_t *data_blocks[MAX_DISKS]; // Pointers to data blocks for parity calc
        int data_count = 0; // Number of data blocks in this stripe

        // Distribute data blocks starting after parity disk
        for (int k = 0; k < N-1; k++) {
            // Calculate which disk gets this block (wrapping around array)
            int disk = (parity_disk + 1 + k) % N;
            
            // Pointer to where this block should go
            uint8_t *target = disks[disk] + stripe * B;
            
            if (block_idx < blocks_in_reg) {
                // Copy data block from input if we have more data
                memcpy(target, reg_disk + block_idx * B, B);
                data_blocks[data_count++] = target; // Add to parity calculation
                block_idx++;
            } else {
                // Zero-fill if we've exhausted input data
                memset(target, 0, B);
                data_blocks[data_count++] = target;
            }
        }

        // Compute and store parity block for this stripe
        compute_parity(disks[parity_disk] + stripe * B, data_blocks, data_count, B);
    }

    // Write all RAID disks to their output files
    for (int i = 0; i < N; i++) {
        if (write_hex_file(disk_paths[i], disks[i], K) != 0) {
            fprintf(stderr, "Failed to write disk %d\n", i);
            // Clean up on error
            for (int j = 0; j < N; j++) free(disks[j]);
            free(reg_disk);
            return 1;
        }
    }

    // Clean up allocated memory
    for (int i = 0; i < N; i++) free(disks[i]);
    free(reg_disk);
    return 0; // Success
}